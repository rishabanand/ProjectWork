package com.cg.mobapp.service;

import java.util.List;

import com.cg.mobapp.dao.MobileDao;
import com.cg.mobapp.dao.MobileDaoImpl;
import com.cg.mobapp.dto.Mobile;
import com.cg.mobapp.exception.MobileException;

public class MobileServiceImpl implements MobileService{

	MobileDao dao;
	public MobileServiceImpl(){
			dao= new MobileDaoImpl();
	}
	@Override
	public int addMobile(Mobile mobile) throws MobileException {
			int id = dao.addMobile(mobile);
		return id;
	}

	@Override
	public Mobile getMobileDetails(int id) throws MobileException {
			return dao.getMobileDetails(id);

	}

	@Override
	public int updateMobile(Mobile mob) throws MobileException {
		return dao.updateMobile(mob);
	}

	@Override
	public int deleteMobile(int id) throws MobileException {
		return dao.deleteMobile(id);
	}

	@Override
	public List<Mobile> getMobileList() throws MobileException {
		return dao.getMobileList();
		
	}

	

}
