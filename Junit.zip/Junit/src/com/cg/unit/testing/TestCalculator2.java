package com.cg.unit.testing;

import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

public class TestCalculator2 {

	static Calculator calc;
	@BeforeClass
	public static void create()
	{
		calc=new Calculator();
	}
	
	@Test
	public void testmultiply()
	{
		int res=calc.multiply(3,8);
		System.out.println("in test multiply()");
		Assert.assertEquals(24,res);
	}
	
	public void testgetMin()
	{
		int min=calc.add(3,8);
		System.out.println("in test multiply()");
		Assert.assertEquals(24,min);
	}
}


