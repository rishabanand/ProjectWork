package com.cg.unit.testing;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;

//import javax.xml.ws.BindingType;

import junit.framework.Assert;

import org.junit.Test;



public class TestCalculator {
	static Calculator calc;
	@BeforeClass
	public static void createObject()
	{
		System.out.println("in create object method");
		 calc = new Calculator();
	}
	
	@AfterClass
	public static void cleanup()
	{
		System.out.println("clean up ");
	}
//@ignore
	
	@Test
	public void testadd(){
		System.out.println("in testadd()");
	//Calculator calc=new Calculator();
	int res=calc.add(3, 8);
	
	Assert.assertEquals(11, res);

}
	@Test
	public void testsub(){
		//Calculator calc=new Calculator();
		int sub=calc.sub(31, 8);
		Assert.assertEquals(23, sub);

}
	
	@Test
	public void testgetmax(){
		//Calculator calc=new Calculator();
		int max=calc.getmax(34, 83);
		Assert.assertEquals(83, max);

}
}