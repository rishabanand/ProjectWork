package com.cg.unit.testing;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;


@RunWith(Suite.class)
@Suite.SuiteClasses({TestCalculator.class,TestCalculator2.class})
public class CalculatorSuite {

}
