package com.cg.unit.testing;

public class Calculator {
	
	
	public int add(int num1,int num2)
	{
		return num1+num2;
	}

	
	public int sub(int num1,int num2)
	{
		return num1-num2;
	}
	
	public int getmax(int num1,int num2)
	{
		if
		(num1>num2)
		return num1;
		
		else
			return num2;
	}
		
		public int multiply(int num1,int num2)
		{
			return num1*num2;
		}
		
		public int min(int num1,int num2)
		{
			if(num1<num2)
				return num1;
			else
				return num2;
		}
		
	}


