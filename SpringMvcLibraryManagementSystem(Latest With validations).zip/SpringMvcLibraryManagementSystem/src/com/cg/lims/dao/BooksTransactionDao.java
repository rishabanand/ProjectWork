package com.cg.lims.dao;

import java.sql.Date;
import java.util.List;

import com.cg.lims.dto.BookTransaction;
import com.cg.lims.dto.BooksInventory;
import com.cg.lims.dto.BooksRegistration;
import com.cg.lims.dto.User;
import com.cg.lims.exception.BooksTransactionException;

public interface BooksTransactionDao 
{
	public String generateTransactionId() throws BooksTransactionException;
	public List<String> getRegIds() throws BooksTransactionException;	
	public void issueBook(BookTransaction bookTransaction) throws BooksTransactionException;	
	public Date getReturnDate(String transactionId) throws BooksTransactionException;	
	public void updateReturnDateAndFine(BookTransaction bookTransaction)throws BooksTransactionException;
	public List<BooksInventory> getBookDetailsByBookName(String bookName)throws BooksTransactionException;
	public List<BooksRegistration> getBookRegistrationDetailsByUserId(String userId)throws BooksTransactionException;
	public void issueBookByBookId(BookTransaction bookTransaction) throws BooksTransactionException;
	public List<BookTransaction> getIssueBookDetailsByUserId(String userId) throws BooksTransactionException;
	public List<String> getReturnBookValueByUserId(String userId) throws BooksTransactionException;	
	public List<String> getUserId() throws BooksTransactionException;
}
