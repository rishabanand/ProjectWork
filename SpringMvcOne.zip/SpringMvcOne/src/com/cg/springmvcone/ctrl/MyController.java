package com.cg.springmvcone.ctrl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.springmvcone.dto.Employee;
import com.cg.springmvcone.service.IEmployeeService;


@Controller
public class MyController
{
	@Autowired
	IEmployeeService employeeService;
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll()
	{
		return "home";
	}
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addEmployee(@ModelAttribute("my") Employee emp
			,Map<String,Object> model)
	{
		List<String> myDesg=new ArrayList<>();
		myDesg.add("Software Engg");
		myDesg.add("Sr Consultant");
		myDesg.add("Manager");
		model.put("deg",myDesg);
		return "addEmployee";
	}
	@RequestMapping(value="insertData", method=RequestMethod.POST)
	public ModelAndView insertEmployee(@Valid @ModelAttribute("my") Employee emp,BindingResult result,Map<String,Object> model)
	{
		int id=0;
		//System.out.println(emp.getEmpName());
		if(result.hasErrors())
		{
			List<String> myDesg=new ArrayList<>();
			myDesg.add("Software Engg");
			myDesg.add("Sr Consultant");
			myDesg.add("Manager");
			model.put("deg",myDesg);
			return new ModelAndView("addEmployee");
		}
		else			
		{
			id=	employeeService.addEmployee(emp);
		}
		return new ModelAndView("success","eData",id);
	}
	@RequestMapping(value="show",method=RequestMethod.GET)
	public ModelAndView showAllEmployee()
	{
		
		List<Employee> myAllData=employeeService.showAllEmployee();
		return new ModelAndView("showAll", "temp", myAllData);
	}
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String deleteEmployee()
	{
		return "deleteEmployee";
	}
	@RequestMapping(value="doDelete",method=RequestMethod.GET)
	public String employeeDelete(@RequestParam("eid") int id)
	{
		employeeService.deleteEmployee(id);
		//System.out.println("Id is "+id);
		return "success";
	}
}
