package com.cg.lims.dao;

import java.sql.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.lims.dto.BookTransaction;
import com.cg.lims.dto.BooksInventory;
import com.cg.lims.dto.BooksRegistration;
import com.cg.lims.dto.User;
import com.cg.lims.exception.BooksTransactionException;

@Repository("booksTransactionDao")
public class BooksTransactionDaoImpl implements BooksTransactionDao
{
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String generateTransactionId() throws BooksTransactionException
	{
		String qry="SELECT 'BT'||to_char(book_tran_id_seq.NEXTVAL,'FM00') FROM DUAL";
		Query query3=entityManager.createNativeQuery(qry);
		return (String) query3.getSingleResult();
	}

	@Override
	public List<String> getRegIds() throws BooksTransactionException 
	{
		List<String> myList=null;
		try
		{
		Query queryOne=entityManager.createQuery("SELECT bookReg.registrationId FROM BooksRegistration bookReg");
		 myList= queryOne.getResultList();
		System.out.println("Hii data is :"+myList);
		
		}
		catch(Exception e)
		{
			throw new BooksTransactionException("Problem in fetching the regIds");
		}	
		return myList;	
	}

	@Override
	public void issueBook(BookTransaction bookTransaction)
			throws BooksTransactionException 
	{
		entityManager.persist(bookTransaction);
		entityManager.flush();	
	}

	@Override
	public Date getReturnDate(String transactionId)
			throws BooksTransactionException 
	{	
		Query selectRegistrationIdQry=entityManager.createQuery("SELECT bookTransaction.returnDate FROM BookTransaction bookTransaction WHERE bookTransaction.transactionId=:tranId");
		selectRegistrationIdQry.setParameter("tranId",transactionId);
		return (Date)selectRegistrationIdQry.getSingleResult();
	}

	@Override
	public void updateReturnDateAndFine(BookTransaction bookTransaction) throws BooksTransactionException 
	{
		try
		{
		Query updateQry=entityManager.createQuery("Update BookTransaction bookT SET bookT.fine=:BookFine,bookT.returnDate=:retDate,bookT.returnBook=:retBook WHERE bookT.transactionId=:tranId");
		updateQry.setParameter("BookFine",bookTransaction.getFine());
		updateQry.setParameter("retDate", bookTransaction.getReturnDate());
		updateQry.setParameter("retBook",bookTransaction.getReturnBook());
		updateQry.setParameter("tranId",bookTransaction.getTransactionId());		
		updateQry.executeUpdate();
		}
		catch(Exception e)
		{
			throw new BooksTransactionException("Problem in updating ");
		}	
	}
	@Override
	public List<BooksInventory> getBookDetailsByBookName(String bookName)
			throws BooksTransactionException 
	{
		Query selectBook=entityManager.createQuery("SELECT booksInventory FROM BooksInventory booksInventory WHERE booksInventory.bookName like :bn");
		//Query selectBook=entityManager.createNativeQuery("SELECT *  FROM BooksInventory  WHERE book_Name like '%:bName%'");
		selectBook.setParameter("bn","%"+bookName+"%");
		return selectBook.getResultList();
	}

	@Override
	public List<BooksRegistration> getBookRegistrationDetailsByUserId(String userId)
			throws BooksTransactionException 
			{
		Query selectQry=entityManager.createQuery("SELECT br FROM BooksRegistration br WHERE br.userId=:uId");
		selectQry.setParameter("uId",userId);
		return selectQry.getResultList();
	}

	@Override
	public void issueBookByBookId(BookTransaction bookTransaction)
			throws BooksTransactionException
	{
		entityManager.persist(bookTransaction);
		entityManager.flush();		
	}
	@Override
	public List<BookTransaction> getIssueBookDetailsByUserId(String userId,String returnBookValue)
			throws BooksTransactionException {
		Query selectQry=entityManager.createQuery("SELECT bookTran FROM BookTransaction bookTran WHERE bookTran.userId=:uId and bookTran.returnBook=:retBookValue");
		selectQry.setParameter("uId",userId);
		selectQry.setParameter("retBookValue",returnBookValue);
		return selectQry.getResultList();
	}
	@Override
	public List<String> getUserId() throws BooksTransactionException 
	{
		Query selectUserIdQry=entityManager.createQuery("SELECT user.userId FROM User user");
		return selectUserIdQry.getResultList();
	}

	@Override
	public List<String> getBookIds() throws BooksTransactionException {
		Query selectUserIdQry=entityManager.createQuery("SELECT bookTran.bookId FROM BookTransaction bookTran");
		return selectUserIdQry.getResultList();
	}

	@Override
	public List<String> getreturnBookValues() throws BooksTransactionException {
		Query selectUserIdQry=entityManager.createQuery("SELECT bookTran.returnBook FROM BookTransaction bookTran");
		return selectUserIdQry.getResultList();
	}

	
}
