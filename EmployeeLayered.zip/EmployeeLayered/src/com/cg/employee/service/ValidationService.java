package com.cg.employee.service;

public interface ValidationService {
	
	public boolean validateFirstName(String name1);
	public boolean validatelastName(String name2);
	public boolean validateMobileNo(String mobno);
	

}
