package com.cg.employee.service;

public class DepartmentServiceImpl {

}
