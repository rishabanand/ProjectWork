package com.cg.employee.service;

public interface DepartmentService {

}
