package com.cg.employee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import com.cg.employee.dto.Department;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.util.DatabaseConnection;


public class DepartmentDaoImpl implements DepartmentDao{
	
	
	Connection connection ;
	public DepartmentDaoImpl() {
		connection= DatabaseConnection.getConnection();
	
	}
	

	@Override
	public int adddepartmentdetails(Department dept) throws EmployeeException {
		
		 String insQry=
					"INSERT INTO department (deptid, deptname) values (?,?) ";
		 try {
				PreparedStatement ps = connection.prepareStatement(insQry);
				
				ps.setInt(1, dept.getDeptid());
				ps.setString(2,dept.getDeptname());
				
				int r= ps.executeUpdate();
				System.out.println(r +"rows inserted...");
				
			} catch (SQLException e) {
				throw new EmployeeException(e.getMessage());
			}
		return 0;



	
	}

}
