package com.cg.employee.dao;

import java.util.List;

import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;

public interface EmployeeDao {
	

	public int addEmployee(Employee emp) throws EmployeeException;
	public List<Employee> getEmployeeList() throws EmployeeException;
	
	public Employee Employeedetails(int empid) throws EmployeeException;
	public int UpdateEmployee(Employee empp) throws EmployeeException;
	


}
