package com.cg.employee.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Date;


import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.util.DatabaseConnection;



public class EmployeeDaoImpl implements EmployeeDao {
	
	Connection connection;
	public EmployeeDaoImpl() {
		connection= DatabaseConnection.getConnection();
	}
	protected void finalize(){
		try {
			connection.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	

	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		
		
		 String insQry=
					"INSERT INTO employee (empid, fname,lname,age,mailid,joiningDate,designation,mobileno,salary) values (empid_seq.nextval,?,?,?,?,?,?,?,?) ";
					try {
						PreparedStatement ps = connection.prepareStatement(insQry);
						
						ps.setString(1, emp.getFname());
						ps.setString(2,emp.getLname());
						ps.setInt(3, emp.getAge());
						ps.setString(4, emp.getMailid());
						ps.setDate(5, emp.getJoiningDate());
						ps.setString(6, emp.getDesignation());
						ps.setString(7, emp.getMobileno());
						ps.setDouble(8, emp.getSalary());
						
						
						
						
						int r= ps.executeUpdate();
						int empid=0;
						if(r==1)
						{
								Statement st= connection.createStatement();
								ResultSet rs= st.executeQuery("select empid_seq.currval from dual");
								if(rs.next())
									empid=rs.getInt(1);
						}
					return empid;
					} catch (SQLException e)
					{
						throw new EmployeeException(e.getMessage());
					}
		
	
	}

	@Override
	public List<Employee> getEmployeeList() throws EmployeeException {
		
		return null;
	}

	@Override
	public Employee Employeedetails(int empid) throws EmployeeException {
	
		return null;
	}

	@Override
	public int UpdateEmployee(Employee empp) throws EmployeeException {
		
		return 0;
	}

}
