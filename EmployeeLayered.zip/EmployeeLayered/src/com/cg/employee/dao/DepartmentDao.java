package com.cg.employee.dao;

import com.cg.employee.dto.Department;
import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;

public interface DepartmentDao {
	
	public int adddepartmentdetails(Department dept) throws EmployeeException;
	
}
