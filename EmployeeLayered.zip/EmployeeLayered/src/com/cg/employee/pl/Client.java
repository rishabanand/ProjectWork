package com.cg.employee.pl;

import java.sql.Date;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.cg.employee.dto.Department;
import com.cg.employee.dto.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.service.EmployeeService;
import com.cg.employee.service.EmployeeServiceImpl;
import com.cg.employee.service.ValidationService;
import com.cg.employee.service.ValidationServiceImpl;


public class Client {
	public static void main(String[] args) {
		Employee emp=new Employee();
		Department dept=new Department();
		EmployeeService service= (EmployeeService) new EmployeeServiceImpl();
		ValidationService validation=new ValidationServiceImpl();
		
		
		Scanner sc=new Scanner(System.in);
		int option=0;
		do
		{
			System.out.println("Add Employee Details");
			System.out.println("List employees");
			System.out.println("Get Employee Details");
			System.out.println("Update Employee Details");
			System.out.println("Add Department details");
			System.out.println("Enter your choice");
			option=sc.nextInt(); 
			
			
			switch(option){
			case 1:
                do{
				System.out.println("Enter First name : ");
				String name1 =sc.next();
				boolean res=validation.validateFirstName(name1);
				if(res==true)
				{

					emp.setFname(name1);
					break;
				}
				else
					System.out.println("Name should contain only alphabets");
                }while(true);
                
                do
                {
				System.out.println("Enter Last name : ");
				String name2 =sc.next();
				
				boolean res=validation.validatelastName(name2);
				if(res==true)
				{

					emp.setFname(name2);
					break;
				}
				else
					System.out.println("Name should contain only alphabets");
                }while(true);
                
				System.out.println("Enter Age: ");
				Integer age =sc.nextInt();
				System.out.println("Enter MailId : ");
				String mailid= sc.next();
				System.out.println("Enter Date of Joining (dd/MM/yyyy) : ");
				String joindate= sc.next();
				
				
				System.out.println("Enter Designation : ");
				String desg= sc.next();
				do
				{
				System.out.println("Enter mobile No :");
				String mobno= sc.next();
				boolean res=validation.validateMobileNo(mobno);
				if(res)
				{
					emp.setMobileno(mobno);
					break;
				}
				else
					System.out.println("Mobile no shoule be 10 digit.");
				}while(true);
				String mobno= sc.next();
				System.out.println("Enter Salary : ");
				Double salary= sc.nextDouble();
				    emp.setAge(age);
					emp.setMailid(mailid);
					emp.setJoiningDate(joiningDate);
					emp.setDesignation(desg);
					
					emp.setSalary(salary);
					
					
				
				try {
					int empid= service.addEmployee(emp);
					System.out.println("Mobile added : "+ empid );
				} catch (EmployeeException e) {
					System.out.println(e.getMessage());
					//logger.info("mobile id does not exists");
				}	
				
				
				break;
				
			case 2:
				
				break;
			case 3:
				
				break;
				
				
			case 4:
				break;
				
			case 5:
				
				//System.out.println("Enter Department Id : ");
				//Integer deptid =sc.nextInt();
				
				System.out.println("Enter Department Name: ");
				String deptname =sc.next();
				break;
				
			default:
				System.out.println("please enter correct option");
			}//end of switch
			
			
			
		}while(option!=4);//end of do while
	}//end of main method

}//end of class
