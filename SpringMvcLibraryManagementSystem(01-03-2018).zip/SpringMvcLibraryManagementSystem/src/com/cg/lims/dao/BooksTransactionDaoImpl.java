package com.cg.lims.dao;

import java.sql.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import com.cg.lims.dto.BookTransaction;
import com.cg.lims.exception.BooksTransactionException;

@Repository("booksTransactionDao")
public class BooksTransactionDaoImpl implements BooksTransactionDao
{
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String generateTransactionId() throws BooksTransactionException
	{
		String qry="SELECT 'BT'||to_char(book_tran_id_seq.NEXTVAL,'FM00') FROM DUAL";
		Query query3=entityManager.createNativeQuery(qry);
		return (String) query3.getSingleResult();
	}

	@Override
	public List<String> getRegIds() throws BooksTransactionException 
	{
		List<String> myList=null;
		try
		{
		Query queryOne=entityManager.createQuery("SELECT bookReg.registrationId FROM BooksRegistration bookReg");
		 myList= queryOne.getResultList();
		System.out.println("Hii data is :"+myList);
		
		}
		catch(Exception e)
		{
			throw new BooksTransactionException("Problem in fetching the regIds");
		}	
		return myList;	
	}

	@Override
	public void issueBook(BookTransaction bookTransaction)
			throws BooksTransactionException 
	{
		entityManager.persist(bookTransaction);
		entityManager.flush();	
	}

	@Override
	public Date getReturnDate(String registrationId)
			throws BooksTransactionException 
	{	
		Query selectRegistrationIdQry=entityManager.createQuery("SELECT bookTransaction.returnDate FROM BookTransaction bookTransaction WHERE bookTransaction.registrationId=:regId");
		selectRegistrationIdQry.setParameter("regId",registrationId);
		return (Date)selectRegistrationIdQry.getSingleResult();
	}

	@Override
	public void updateReturnDateAndFine(BookTransaction bookTransaction) throws BooksTransactionException 
	{
		Query updateQry=entityManager.createQuery("Update BookTransaction SET fine=:BookFine , returnDate=:retDate WHERE registrationId=:regId");
		updateQry.setParameter("BookFine",bookTransaction.getFine());
		updateQry.setParameter("retDate", bookTransaction.getReturnDate());
		updateQry.setParameter("regId",bookTransaction.getRegistrationId());
		updateQry.executeUpdate();
	}

	@Override
	public String getBookIdByRegistrationId(String registrationId)
			throws BooksTransactionException 
	{
		return null;
	}

}
