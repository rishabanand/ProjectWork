package com.cg.lims.controller;

import java.sql.Date;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.lims.dto.BookTransaction;
import com.cg.lims.exception.BooksTransactionException;
import com.cg.lims.service.BooksTransactionService;
@Controller
public class LibraryController 
{
	@Autowired
	BooksTransactionService booksTransactionService;
	@RequestMapping(value="bookTransaction",method=RequestMethod.GET)
	public String showIssueBookPage(Model model)
	{
		model.addAttribute("bookTransaction",new BookTransaction());
		return "showIssueBookPage";
	}
	@RequestMapping(value="issueBook",method=RequestMethod.POST)
	public ModelAndView issueBook(@ModelAttribute("bookTransaction") BookTransaction issueBookTransaction)
	{
		try 
		{
			Date issueDate=issueBookTransaction.getIssueDate();
			LocalDate issueDate1=issueDate.toLocalDate();
			LocalDate returnDate=issueDate1.plusDays(14);
			Date returnDate1=Date.valueOf(returnDate);
			//System.out.println("Data is"+issueBookTransaction);
			//System.out.println("Id is :"+booksTransactionService.generateTransactionId());
			issueBookTransaction.setTransactionId(booksTransactionService.generateTransactionId());
			issueBookTransaction.setReturnDate(returnDate1);
			issueBookTransaction.setFine(0);
			//System.out.println("Data is : "+issueBookTransaction);
			booksTransactionService.issueBook(issueBookTransaction);
		} 
		catch (BooksTransactionException e)
		{
			e.printStackTrace();
		}
		
		return new ModelAndView("issueBookSuccessPage","temp",issueBookTransaction);
	}
	@RequestMapping(value="mainMenu",method=RequestMethod.POST)
	public String mainMenu(Model model)
	{
		model.addAttribute("bookTransaction", new BookTransaction());
		return "redirect:/issueBook";
	}
}
