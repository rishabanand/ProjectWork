package com.cg.lims.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.lims.dto.BookTransaction;
import com.cg.lims.dto.BooksInventory;
import com.cg.lims.dto.BooksRegistration;
import com.cg.lims.exception.BooksTransactionException;
import com.cg.lims.service.BooksTransactionService;
@Controller
public class LibraryController 
{
	@Autowired
	BooksTransactionService booksTransactionService;
	
	
	@RequestMapping(value="mainMenu",method=RequestMethod.GET)
	public String mainMenu(Model model)
	{
		model.addAttribute("bookTransaction", new BookTransaction());
		return "redirect:/bookTransaction";
	}
	@RequestMapping(value="returnBookTransaction",method=RequestMethod.GET)
	public String showReturnBookPage(Model model)
	{
		model.addAttribute("returnBookTransaction",new BookTransaction());
		return "returnBookPage";
	}
	@RequestMapping(value="returnBook",method=RequestMethod.POST)
	public ModelAndView returnBook(@ModelAttribute("returnBookTransaction") BookTransaction returnBookTransaction) throws BooksTransactionException
	{
		try
		{
			int fine=booksTransactionService.calculateFine(returnBookTransaction);
			returnBookTransaction.setFine(fine);	
			System.out.println("Fine is : "+fine);		
			booksTransactionService.updateReturnDateAndFine(returnBookTransaction);		
			return new ModelAndView("ReturnBookSuccessPage","temp",returnBookTransaction);
		}
		catch(Exception e)
		{
			String errorMssg=e.getMessage();			
			return new ModelAndView("Error","temp",errorMssg);
		}
	}
	@RequestMapping(value="loginPage",method=RequestMethod.GET)
	public String getLoginPage()
	{
		return "Login";
	}
	@RequestMapping(value="bookTransactionPage",method=RequestMethod.GET)
	public String getBookTransactionPage()
	{
		return "Index";
	}
	@RequestMapping(value="mainBookTransaction",method=RequestMethod.GET)
	public String getBooksRequestByBookName()
	{
		return "DisplayBookDetails";
	}
	@RequestMapping(value="getBookDetail",method=RequestMethod.GET)
	public ModelAndView getBookDetail(@RequestParam("bookName") String bookName)
	{
		List<BooksInventory> bookDetails=null;
		try 
		{
		 bookDetails=booksTransactionService.getBookDetailsByBookName(bookName);
			
			System.out.println("Data is  : "+bookDetails);
			return new ModelAndView("SuccesBookDetails","bookDetails",bookDetails);
			
		} 
		catch (BooksTransactionException e)
		{
		
		}
		return new ModelAndView("Error","temp","No Records Found");
	}
	@RequestMapping(value="issueBookByBookName",method=RequestMethod.GET)
	public String issueBookBySearchingBook(@RequestParam("bookId") String bookId, Model model)
	{
		model.addAttribute("bookId", bookId);
		return "GetIssueDatePage";
	}
	@RequestMapping(value="issueBookByBookName",method=RequestMethod.GET)
	public ModelAndView issueBookByBookName()
	{
		return null;
	}
	@RequestMapping(value="issueBookByUserId",method=RequestMethod.GET)
	public String searchUserRequestById()
	{
		return "SearchUserRequestDetails";
	}
	@RequestMapping(value="getRegistrationDetails",method=RequestMethod.GET)
	public ModelAndView getUserId(@RequestParam("userId") String userId)
	{
		List<BooksRegistration> bookRegistrationDetails=null;
		try 
		{
			bookRegistrationDetails=booksTransactionService.getBookRegistrationDetailsByUserId(userId);
			System.out.println("Data is  :"+bookRegistrationDetails);
			//model.addAttribute("bookregisDetails", bookRegistrationDetails);
		} 
		catch (BooksTransactionException e) 
		{
			e.printStackTrace();
		}
		return new ModelAndView("ShowRegistartionDetailsPage","bookregisDetails",bookRegistrationDetails);
	}
	@RequestMapping(value="issueBookByDate",method=RequestMethod.GET)
	public String showIssueBookPage(Model model,@RequestParam("regId") String regId)
	{
		model.addAttribute("bookTransaction",new BookTransaction());
		model.addAttribute("registrationId", regId);
		return "showIssueBookPage";
	}
	@RequestMapping(value="issueBook",method=RequestMethod.POST)
	public ModelAndView issueBook(@ModelAttribute("bookTransaction") BookTransaction issueBookTransaction) throws BooksTransactionException
	{
		try 
		{
			Date issueDate=issueBookTransaction.getIssueDate();
			LocalDate issueDate1=issueDate.toLocalDate();
			LocalDate returnDate=issueDate1.plusDays(14);
			Date returnDate1=Date.valueOf(returnDate);
			issueBookTransaction.setTransactionId(booksTransactionService.generateTransactionId());
			issueBookTransaction.setReturnDate(returnDate1);
			issueBookTransaction.setFine(0);
			if(booksTransactionService.validateRegId(issueBookTransaction.getRegistrationId()))
			{
				booksTransactionService.issueBook(issueBookTransaction);
				return new ModelAndView("issueBookSuccessPage","temp",issueBookTransaction);
			}
			else
			{
				return new ModelAndView("Error","temp","Invalid Registration Id. Please check It.....");
			}
		} 
		catch ( Exception e)
		{			
			String errorMssg=e.getMessage();			
			return new ModelAndView("Error","temp",errorMssg);
		}		
	}
	
}
