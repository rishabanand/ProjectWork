package com.cg.lims.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.lims.dto.BookTransaction;
import com.cg.lims.exception.BooksTransactionException;
import com.cg.lims.exception.RegistrationException;
@Repository("booksTransactionDao")
public class BooksTransactionDaoImpl implements BooksTransactionDao
{
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String generateTransactionId() throws BooksTransactionException
	{
		String qry="SELECT 'BT'||to_char(book_tran_id_seq.NEXTVAL,'FM00') FROM DUAL";
		Query query3=entityManager.createNativeQuery(qry);
		return (String) query3.getSingleResult();
	}

	@Override
	public List<String> getRegIds() throws RegistrationException 
	{
		Query queryOne=entityManager.createQuery("SELECT bookReg.registration_id FROM BooksRegistration bookReg");
		List<String> myList= queryOne.getResultList();
		return myList;		
	}

	@Override
	public void issueBook(BookTransaction bookTransaction)
			throws BooksTransactionException 
	{
		entityManager.persist(bookTransaction);
		entityManager.flush();	
	}

	@Override
	public Date getReturnDate(String registrationId)
			throws BooksTransactionException 
	{
		
		return null;
	}

	@Override
	public int updateReturnDateAndFine(String registrationId, int fine,
			LocalDate returnDate) throws BooksTransactionException 
	{
		
		return 0;
	}

	@Override
	public String getBookIdByRegistrationId(String registrationId)
			throws BooksTransactionException 
	{
		return null;
	}

}
