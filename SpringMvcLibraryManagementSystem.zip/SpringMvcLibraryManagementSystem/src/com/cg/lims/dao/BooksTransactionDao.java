package com.cg.lims.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import com.cg.lims.dto.BookTransaction;
import com.cg.lims.exception.BooksTransactionException;
import com.cg.lims.exception.RegistrationException;

public interface BooksTransactionDao 
{
	public String generateTransactionId() throws BooksTransactionException;
	public List<String> getRegIds() throws RegistrationException;
	public void issueBook(BookTransaction bookTransaction) throws BooksTransactionException;
	
	public Date getReturnDate(String registrationId) throws BooksTransactionException;
	public int updateReturnDateAndFine(String registrationId,int fine,LocalDate returnDate)throws BooksTransactionException;
	public String getBookIdByRegistrationId(String registrationId)throws BooksTransactionException;
}
