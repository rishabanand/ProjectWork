package com.cg.lims.dao;

import com.cg.lims.dto.BooksInventory;
import com.cg.lims.exception.BookInventoryException;

public interface BooksInventoryDao
{
	public int addBookInventory(BooksInventory bookInv) throws BookInventoryException;
	public String generateBookId() throws BookInventoryException;
	public int deleteBook(String bId) throws BookInventoryException;
}
