package com.cg.lims.service;

import java.util.List;

import com.cg.lims.dto.BookTransaction;
import com.cg.lims.exception.BooksTransactionException;
import com.cg.lims.exception.RegistrationException;

public interface BooksTransactionService 
{
	public String generateTransactionId() throws BooksTransactionException;
	public List<String> getRegIds() throws RegistrationException;
	public void issueBook(BookTransaction bookTransaction) throws BooksTransactionException;
}
