package com.cg.lims.service;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.lims.dao.BooksTransactionDao;
import com.cg.lims.dto.BookTransaction;
import com.cg.lims.dto.BooksInventory;
import com.cg.lims.dto.BooksRegistration;
import com.cg.lims.exception.BooksTransactionException;
@Service("booksTransactionService")
@Transactional
public class BooksTransactionServiceImpl implements BooksTransactionService
{
	@Autowired
	BooksTransactionDao booksTransactionDao;

	@Override
	public String generateTransactionId() throws BooksTransactionException
	{
		return booksTransactionDao.generateTransactionId();
	}

	@Override
	public List<String> getRegIds() throws BooksTransactionException 
	{
		return booksTransactionDao.getRegIds();
	}

	@Override
	public void issueBook(BookTransaction bookTransaction)
			throws BooksTransactionException
	{
		booksTransactionDao.issueBook(bookTransaction);
	}

	@Override
	public boolean validateRegId(String RegId) throws BooksTransactionException 
	{
		
		List<String> regIds=booksTransactionDao.getRegIds();
		for(String tempbookIds :regIds)
		{
			if(RegId.equals(tempbookIds))
			{
				return true;
			}
		}		
		throw new BooksTransactionException("Invalid Registration Id. Please check it");
	}

	@Override
	public int calculateFine(BookTransaction bookTransaction)
			throws BooksTransactionException 
	{
		LocalDate currentDate=bookTransaction.getReturnDate().toLocalDate();
		//int month=returnDate.getMonthValue();
		//int year=returnDate.getYear();
		//int day=returnDate.getDayOfMonth();
		//LocalDate currentDate=LocalDate.of(year,month,day);
		LocalDate returnDateFromTable=null ;
		int fine=0;
		
			returnDateFromTable = booksTransactionDao.getReturnDate(bookTransaction.getRegistrationId()).toLocalDate();
			if(currentDate.isAfter(returnDateFromTable))
			{
				fine=1*(currentDate.getDayOfYear()-returnDateFromTable.getDayOfYear());
			}
			else 
			{
				fine=0;
			}		
	
			return fine;
	}
	@Override
	public void updateReturnDateAndFine(BookTransaction bookTransaction)
			throws BooksTransactionException
	{
		booksTransactionDao.updateReturnDateAndFine(bookTransaction);		
	}

	@Override
	public List<BooksInventory> getBookDetailsByBookName(String bookName)
			throws BooksTransactionException {
		// TODO Auto-generated method stub
		return booksTransactionDao.getBookDetailsByBookName(bookName);
	}

	@Override
	public List<BooksRegistration> getBookRegistrationDetailsByUserId(String userId)
			throws BooksTransactionException {
		// TODO Auto-generated method stub
		return booksTransactionDao.getBookRegistrationDetailsByUserId(userId);
	}

	@Override
	public void issueBookByBookId(BookTransaction bookTransaction)
			throws BooksTransactionException {
		booksTransactionDao.issueBookByBookId(bookTransaction);
		
	}

}
