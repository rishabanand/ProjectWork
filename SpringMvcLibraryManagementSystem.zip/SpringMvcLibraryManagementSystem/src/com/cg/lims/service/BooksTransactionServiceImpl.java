package com.cg.lims.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.lims.dao.BooksTransactionDao;
import com.cg.lims.dto.BookTransaction;
import com.cg.lims.exception.BooksTransactionException;
import com.cg.lims.exception.RegistrationException;
@Service("booksTransactionService")
@Transactional
public class BooksTransactionServiceImpl implements BooksTransactionService
{
	@Autowired
	BooksTransactionDao booksTransactionDao;

	@Override
	public String generateTransactionId() throws BooksTransactionException
	{
		return booksTransactionDao.generateTransactionId();
	}

	@Override
	public List<String> getRegIds() throws RegistrationException 
	{
		return booksTransactionDao.getRegIds();
	}

	@Override
	public void issueBook(BookTransaction bookTransaction)
			throws BooksTransactionException
	{
		booksTransactionDao.issueBook(bookTransaction);
	}

}
