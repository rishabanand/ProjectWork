package com.cg.logger.demo;
import org.apache.log4j.Logger;

import org.apache.log4j.PropertyConfigurator;

import com.cg.logger.demo.Calculator;
public class LoggerDemo {
	
	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");
		Calculator cal=new Calculator();
		Logger logger=Logger.getLogger(LoggerDemo.class);
		System.out.println("please see the basic.log file for log messages");
		int addres=cal.add(46, 74);
		int subres=cal.subtract(73, 34);
		double divres=cal.divide(354,0);
		int mulres=cal.multiply(5,4);
		
		logger.info("Addition result:"+addres);
		logger.info("sub result:"+subres);
		logger.info("div result:"+divres);
		logger.info("mul result:"+mulres);
		
		
		logger.debug("this is a debug level message");
		logger.info("This is a info message");
		logger.warn("This is a warn level message");
		logger.error("This is a error level message");
		logger.fatal("This is a fatal level message");
	}

}
