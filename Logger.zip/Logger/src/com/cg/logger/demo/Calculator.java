package com.cg.logger.demo;


import org.apache.log4j.Logger;


public class Calculator {
	
private static Logger logger=Logger.getLogger("Calculator");
public int  add(int num1,int num2)
{
	logger.info("In add method");
	return num1+num2;
}
	public int subtract(int num1,int num2){
		logger.info("In subtract method");
		return num1-num2;
	}
	
	public double divide(int num1,int num2)
	{
		logger.info("in divide method");
		try
		{
			if(num2==0)
			
				throw new ArithmeticException();
				return (double)num1/num2;
				
		}
		catch(ArithmeticException e)
			{
				logger.error("num2 is 0");
			}
			return 0;
		}
		
		public int multiply(int num1,int num2)
		{
			logger.info("in multiply method");
			return num1*num2;
		}
	}


