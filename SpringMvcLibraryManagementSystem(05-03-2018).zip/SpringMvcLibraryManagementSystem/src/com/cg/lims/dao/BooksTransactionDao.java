package com.cg.lims.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import com.cg.lims.dto.BookTransaction;
import com.cg.lims.exception.BooksTransactionException;

public interface BooksTransactionDao 
{
	public String generateTransactionId() throws BooksTransactionException;
	public List<String> getRegIds() throws BooksTransactionException;
	public void issueBook(BookTransaction bookTransaction) throws BooksTransactionException;
	
	public Date getReturnDate(String registrationId) throws BooksTransactionException;
	public void updateReturnDateAndFine(BookTransaction bookTransaction)throws BooksTransactionException;
	public String getBookIdByRegistrationId(String registrationId)throws BooksTransactionException;
}
