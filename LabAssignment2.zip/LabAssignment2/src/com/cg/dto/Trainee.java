package com.cg.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
@Entity
@Table(name="trainee_mgt")
public class Trainee 
{
	@Id	
	@NotNull(message="Salary should not be empty")
	private Integer traineeId;
	@Pattern(regexp="[A-Z][a-zA-Z]{2,}",message="Name should only contain "
			+ "only chracters and must be start with capital letters and contain"
			+ " min 3 characters ")
	private String traineeName;
	private String traineeDomain;
	private String traineeLocation;
	
	
	public Integer getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(Integer traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() 
	{
		return traineeName;
	}
	public void setTraineeName(String traineeName)
	{
		this.traineeName = traineeName;
	}
	public String getTraineeDomain() 
	{
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain)
	{
		this.traineeDomain = traineeDomain;
	}
	public String getTraineeLocation() 
	{
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation)
	{
		this.traineeLocation = traineeLocation;
	}
	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", traineeName="
				+ traineeName + ", traineeDomain=" + traineeDomain
				+ ", traineeLocation=" + traineeLocation + "]";
	}	
	
}
