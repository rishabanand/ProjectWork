package com.cg.service;

import java.util.List;

import com.cg.dto.Trainee;

public interface TraineeService
{
	public void addEmployee(Trainee trainee);
	public void deleteTraineeById(int traineeId);
	public Trainee fetchTraineeById(int traineeId);
	public List<Trainee> showAllTrainee();
	public void updateTrainee(Trainee trainee);
}
