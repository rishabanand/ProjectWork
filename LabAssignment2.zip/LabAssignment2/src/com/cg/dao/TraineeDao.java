package com.cg.dao;

import java.util.List;

import com.cg.dto.Trainee;

public interface TraineeDao
{
	public void addTrainee(Trainee trainee);
	public void deleteTraineeById(int traineeId);
	public Trainee fetchTraineeById(int traineeId);
	public List<Trainee> showAllTrainee();
	public void updateTrainee(Trainee trainee);
}
